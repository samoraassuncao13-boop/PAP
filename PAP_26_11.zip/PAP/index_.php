<!DOCTYPE html>
<html lang="pt-PT">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PAP</title>
</head>
<link rel="stylesheet" href="templates/css/style.css">
<body>
  <script> scr="templates/js/script.js"<cript/>
</body>
</html>